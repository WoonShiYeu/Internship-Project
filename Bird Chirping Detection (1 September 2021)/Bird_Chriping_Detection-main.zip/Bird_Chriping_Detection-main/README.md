# Bird_Chriping_Detection

This program can be used directly with Arduino Nano Sense and OLED 3106 display.

This would detect songs on bird Mynah / Asian Koel.

Arduino Library from EdgeImpulse - ei-birds_detection-arduino-1.0.5.zip

Arduino Program - nano_ble33_sense_microphone_continuous_AY.ino

Circuit Diagram - Wire_Diagram.png

Demo - https://youtu.be/9ibp7H7qPnk

Please add original library via Arduino IDE - ei-birds_detection-arduino-1.0.5.zip
Then try to upload program 'nano_ble33_sense_microphone_continuous_AY.ino'

Note : I found uploading sketch via RaspberryPi 400 is quite faster than via Windows laptop.
Possibility is my laptop is quite out dated :)